const CACHE='reap-life-life-memo-v15';
const CORE=['./','./index.html','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png','./icons/icon-512-maskable.png'];
self.addEventListener('install',event=>{
 event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(CORE)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
 event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
 const req=event.request;
 if(req.method!=='GET')return;
 event.respondWith(
   caches.match(req).then(cached=>{
     if(cached)return cached;
     return fetch(req).then(resp=>{
       if(resp && resp.ok && new URL(req.url).origin===self.location.origin){
         const copy=resp.clone();
         caches.open(CACHE).then(c=>c.put(req,copy)).catch(()=>{});
       }
       return resp;
     }).catch(()=>cached||new Response('Offline',{status:503,statusText:'Offline'}));
   })
 );
});
