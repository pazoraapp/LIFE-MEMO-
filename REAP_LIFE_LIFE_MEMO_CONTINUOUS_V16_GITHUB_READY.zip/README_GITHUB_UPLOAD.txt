GITHUB READY V16

Upload these items to the ROOT of your reap-life-memo repository:
index.html
manifest.webmanifest
service-worker.js
icons/
assets/
Do not upload this ZIP as the Pages website.
