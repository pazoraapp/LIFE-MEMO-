GITHUB READY — REAP LIFE LIFE MEMO V15

Upload the CONTENTS of this folder to the ROOT of your GitHub repository.
Do NOT upload only the ZIP if you want GitHub Pages to run the app.

Required root items:
index.html
manifest.webmanifest
service-worker.js
icons/
assets/

After upload: GitHub repository > Settings > Pages > Deploy from branch > main > /(root) > Save.
